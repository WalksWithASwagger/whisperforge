# Usage for this pattern:

```bash
git diff
```

Get the diffs since the last commit
```bash
git show HEAD
```

